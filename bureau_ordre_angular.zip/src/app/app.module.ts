import { NgModule } from '@angular/core';
import { HashLocationStrategy, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { BrowserModule, Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import {
  PERFECT_SCROLLBAR_CONFIG,
  PerfectScrollbarConfigInterface,
  PerfectScrollbarModule,
} from 'ngx-perfect-scrollbar';

// Import routing module
import { AppRoutingModule } from './app-routing.module';

// Import app component
import { AppComponent } from './app.component';

// Import containers
import {
  DefaultFooterComponent,
  DefaultHeaderComponent,
  DefaultLayoutComponent,
} from './containers';

import {
  AvatarModule,
  BadgeModule,
  BreadcrumbModule,
  ButtonGroupModule,
  ButtonModule,
  CardModule,
  DropdownModule,
  FooterModule,
  FormModule,
  GridModule,
  HeaderModule,
  ListGroupModule,
  NavModule,
  ProgressModule,
  SharedModule,
  SidebarModule,
  TableModule,
  TabsModule,
  UtilitiesModule,
  ModalModule,
} from '@coreui/angular';

import { IconModule, IconSetService } from '@coreui/icons-angular';
import { UtilisateursComponent } from './views/utilisateurs/utilisateurs.component';
import { etudiantsComponent } from './views/utilisateurs/etudiants/etudiants.component';
import { modifierutilisateurComponent } from './views/utilisateurs/modifierutilisateur/modifierutilisateur.component';
import { enseignantsComponent } from './views/utilisateurs/enseignants/enseignants.component';
import { demandesAdhesionComponent } from './views/utilisateurs/demandes_adhesion/demandes_adhesion.component';
import { DemandesComponent } from './views/demandes/demandes.component';
import { AuthGuard } from './auth.guard';
import { LoggedGuard } from './logged.guard';
import { adminGuard } from './admin.guard';
import { PagesModule }  from './views/pages/pages.module';
import { UtilisateurService } from './utilisateur.service';
import { demandeService } from './demande.service';
import { HttpClientModule } from '@angular/common/http';
import { accepterdemandeComponent } from './views/demandes/accepterdemande/accepterdemande.component';
import { refuserdemandeComponent } from './views/demandes/refuserdemande/refuserdemande.component';
import { soumettredemandeComponent } from './views/demandes/soumettredemande/soumettredemande.component';
import { DemandesrefuseesComponent } from './views/demandes/demandesrefusees/demandesrefusees.component';
import { ProfileComponent } from './views/pages/profile/profile.component';
import { MesdemandesComponent } from './views/demandes/mesdemandes/mesdemandes.component';
import { DemandesapprouveesComponent } from './views/demandes/demandesapprouvees/demandesapprouvees.component';
import { modifiercategoriedemandeComponent } from './views/demandes/modifiercategoriedemande/modifiercategoriedemande.component';
import { ModifiermotdepasseComponent } from './views/pages/modifiermotdepasse/modifiermotdepasse.component';
import { MotdepasseoublieComponent } from './views/pages/motdepasseoublie/motdepasseoublie.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';


import { statistiquesService } from './statistiques.service';
import { categorieService } from './categorie.service';
import { CategoriesComponent }  from './views/categories/categories.component';




const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true,
};

const APP_CONTAINERS = [
  DefaultFooterComponent,
  DefaultHeaderComponent,
  DefaultLayoutComponent,
];

@NgModule({
  declarations: [
    AppComponent,
    ...APP_CONTAINERS,
    UtilisateursComponent,
    etudiantsComponent,
    enseignantsComponent,
    DashboardComponent,
    demandesAdhesionComponent,
    DemandesComponent,
    refuserdemandeComponent,
    modifierutilisateurComponent,
    accepterdemandeComponent,
    soumettredemandeComponent,
    DemandesrefuseesComponent,
    DemandesapprouveesComponent,
    MesdemandesComponent,
    ProfileComponent,
    ModifiermotdepasseComponent,
    MotdepasseoublieComponent,
    modifiercategoriedemandeComponent,
    CategoriesComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AvatarModule,
    BreadcrumbModule,
    FooterModule,
    ModalModule,
    DropdownModule,
    GridModule,
    HeaderModule,
    HttpClientModule,
    SidebarModule,
    IconModule,
    PerfectScrollbarModule,
    NavModule,
    ButtonModule,
    FormModule,
    PagesModule,
    UtilitiesModule,
    ButtonGroupModule,
    ReactiveFormsModule,
    FormsModule,
    SidebarModule,
    SharedModule,
    TabsModule,
    ListGroupModule,
    ProgressModule,
    BadgeModule,
    ListGroupModule,
    TableModule,
    CardModule,
  ],
  providers: [
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy,
    },
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG,
    },
    IconSetService,
    Title,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

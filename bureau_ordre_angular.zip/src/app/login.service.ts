import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  private apiUrl: string = 'http://localhost:3000/api';
  private loggedIn = false;

  constructor(private http: HttpClient) {}

  // Authenticate a user
  authentifierUtilisateur(credentials: any): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/utilisateurs/authentifier`,
      credentials
    );
  }

  saveRole(role: string) {
    localStorage.setItem("Role", role);
  }

  getRole() {
    return localStorage.getItem("Role");
  }

  saveName(token: string) {
    localStorage.setItem("nom", token);
  }

  getName() {
    return localStorage.getItem("nom");
  }

  saveID(token: string) {
    localStorage.setItem("ID", token);
  }

  getID() {
    return localStorage.getItem("ID");
  }

  deleteData() {
    localStorage.removeItem("Role");
    localStorage.removeItem("ID");
    localStorage.removeItem("nom");
  }

  isLoggedIn() {
    const usertoken = this.getID();
    if (usertoken != null) {
      return true;
    }
    return false;
  }
}

import { Component } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { LoginService } from 'src/app/login.service';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent {
  userId: any;
  modifierForm: any;
  profile: any;
  modifierprofile:any;
  constructor(
    private utilisateurService: UtilisateurService,
    private fb: FormBuilder,
    private loginService: LoginService
  ) {}

  ngOnInit() {
    this.userId = this.loginService.getID();
    this.afficherProfile();
    this.modifierprofile = false;
    this.modifierForm = this.fb.group({
      nom: ['', Validators.required],
      prenom: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      cin: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(8),
          Validators.pattern('[0-9]*'),
        ],
      ],
      phone: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(8),
          Validators.pattern('[0-9]*'),
        ],
      ],
    });
  }
  afficherProfile() {
    this.utilisateurService
      .afficherUtilisateurParID(this.userId)
      .subscribe((res) => {
        this.profile = res;
        console.log(this.profile);
          this.modifierForm.patchValue({
            nom: this.profile.nom,
            prenom: this.profile.prenom,
            email: this.profile.email,
            cin: this.profile.cin,
            phone: this.profile.phone
      });
  });
}

  modifierUtilisateur(modifierForm: any) {
    this.utilisateurService
      .modifierUtilisateurParID(this.userId, modifierForm)
      .subscribe(
        (res) => {
          alert('modifié');
          this.afficherProfile();
        },
        (err) => {
          console.log(err);
          alert('Erreur lors de la modification');
        }
      );
  }

  modifier() {
    this.modifierprofile = !this.modifierprofile;
    console.log(this.modifierprofile);
  }

}

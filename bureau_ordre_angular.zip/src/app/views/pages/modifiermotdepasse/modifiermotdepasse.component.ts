import { Component } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { LoginService } from 'src/app/login.service';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-modifiermotdepasse',
  templateUrl: './modifiermotdepasse.component.html',
  styleUrls: ['./modifiermotdepasse.component.scss'],
})
export class ModifiermotdepasseComponent {
  userId: any;
  modifiermdpForm: any;
  constructor(
    private utilisateurService: UtilisateurService,
    private fb: FormBuilder,
    private loginService: LoginService
  ) {}

  ngOnInit() {
    this.userId = this.loginService.getID();
    this.modifiermdpForm = this.fb.group({
      ancien_mdp: ['', Validators.required],
      nouveau_mdp: ['', Validators.required],
      conf_nouveau_mdp: ['', [Validators.required]],
    });
  }

  modifierUtilisateur(modifiermdpForm: any) {
    if  (
      modifiermdpForm.nouveau_mdp !==
      modifiermdpForm.conf_nouveau_mdp
    ) {
      alert('Les mots de passe ne correspondent pas');
      return;
    }
    this.utilisateurService
      .modifierMotdepass(this.userId, modifiermdpForm)
      .subscribe(
        (res) => {
          alert('modifié');
        },
        (err) => {
          console.log(err);
          alert('Erreur lors de la modification');
        }
      );
  }

}

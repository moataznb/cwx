import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/login.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UtilisateurService } from 'src/app/utilisateur.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  loginForm: any;
  isLogged: any;
  constructor(
    private loginService: LoginService,
    private router: Router,
    private fb: FormBuilder,
    private utilisateurService: UtilisateurService
  ) {}

  authentifier(loginForm: any) {
    let logindata = {
      email: loginForm.value.email,
      password: loginForm.value.password,
    }
    console.log(logindata);
    this.loginService.authentifierUtilisateur(logindata).subscribe(
      (res) => {
        if (res != null) {
        this.utilisateurService.afficherUtilisateurParID(res._id).subscribe(
          (res) => {
            console.log(res);
            if (res.verified == true) {
             this.loginService.saveRole(res.role);
             this.loginService.saveID(res._id);
             this.loginService.saveName(res.nom + ' ' + res.prenom);
             this.router.navigate(['/dashboard']);
            } else {
              alert('Votre compte est en attente de validation par l\'administrateur');
            }
          });
        }
      },
      (err) => {
        alert('Erreur lors de l\'authentification');
      }
    );
  }

  changerPage(lien:any){
    this.router.navigate([lien]);
  }
  
  ngOnInit() {
    this.isLogged = this.loginService.isLoggedIn();
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }
}

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/login.service';
import { UtilisateurService } from 'src/app/utilisateur.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent {
  isLogged: any;
  FormInscrire: any;
  constructor(
    private loginService: LoginService,
    private router: Router,
    private fb: FormBuilder,
    private utilisateurService: UtilisateurService
  ) {}

  ngOnInit() {
    this.isLogged = this.loginService.isLoggedIn();
    this.FormInscrire = this.fb.group({
      nom: ['', Validators.required],
      prenom: ['', Validators.required],
      cin: [
        '',
        [
          Validators.required,
          Validators.pattern('^[0-9]*$'),
          Validators.minLength(8),
          Validators.maxLength(8),
        ],
      ],
      email: ['', [Validators.required, Validators.email]],
      phone: [
        '',
        [
          Validators.required,
          Validators.pattern('^[0-9]*$'),
          Validators.minLength(8),
          Validators.maxLength(8),
        ],
      ],
      role: ['', Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required],
    });
  }

  inscrire(FormInscrire: any) {
    if (FormInscrire.password != FormInscrire.confirmPassword) {
      alert('Les mots de passe ne correspondent pas');
      return;
    }

    this.utilisateurService.inscrireUtilisateur(FormInscrire).subscribe(
      (res) => {
        console.log(res);
        this.router.navigate(['/login']);
      },
      (err) => {
        alert('Erreur');
        console.error(err.error.message);
        console.error(err.error);
      }
    );
  }

  changerPage(lien: any) {
    this.router.navigate([lien]);
  }
  
}

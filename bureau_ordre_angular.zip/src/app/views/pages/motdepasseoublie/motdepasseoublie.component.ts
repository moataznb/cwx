import { Component } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { LoginService } from 'src/app/login.service';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-motdepasseoublie',
  templateUrl: './motdepasseoublie.component.html',
  styleUrls: ['./motdepasseoublie.component.scss'],
})
export class MotdepasseoublieComponent {
  userId: any;
  mdpoublieform: any;
  constructor(
    private utilisateurService: UtilisateurService,
    private fb: FormBuilder,
    private loginService: LoginService
  ) {}

  ngOnInit() {
    this.userId = this.loginService.getID();
    this.mdpoublieform = this.fb.group({
      email: ['', [Validators.required,Validators.email]],
    });
  }

  modifierUtilisateur(mdpoublieform: any) {
    this.utilisateurService.motdepasseoublie(mdpoublieform).subscribe(
      (res) => {
        alert('votre mot de passe a eté reinitialisé \nveuillez consulter votre boite mail.');
      },
      (err) => {
        console.log(err);
        alert('Erreur lors de la reinitialisation de votre mot de passe\n aucun compte n\'est associé à cette adresse mail');
      }
    );
  }

}

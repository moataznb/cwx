import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup } from '@angular/forms';

import { statistiquesService } from 'src/app/statistiques.service';
import { tap } from 'rxjs';
import { forkJoin } from 'rxjs';

import * as Chart from 'chart.js';

@Component({
  templateUrl: 'dashboard.component.html',
  styleUrls: ['dashboard.component.scss'],
})
export class DashboardComponent implements OnInit {
  nbrutilisateurs: any;
  nbretudiants: any;
  nbrenseignants: any;
  nbrdemandes: any;
  nbrdemandeapprouvees: any;
  nbrdemandesenattente: any;
  nbrdemanderefusees:any;
  constructor(private statsService: statistiquesService) {}

  ngOnInit(): void {
    this.obtenirStatistiques().subscribe(() => {
      console.log(
        this.nbrdemandeapprouvees,
        this.nbrdemandes,
        this.nbrdemandesenattente,
        this.nbrenseignants,
        this.nbretudiants,
        this.nbrutilisateurs,
        this.nbrdemanderefusees
      );
    });
  }

  obtenirStatistiques() {
    const nbrUtilisateurs$ = this.statsService.obtenirNbrUtilisateurs().pipe(
      tap((res: any) => {
        this.nbrutilisateurs = res;
      })
    );

    const nbrEtudiants$ = this.statsService.obtenirNbrEtudiants().pipe(
      tap((res: any) => {
        this.nbretudiants = res;
      })
    );

    const nbrEnseignants$ = this.statsService.obtenirNbrEnseignants().pipe(
      tap((res: any) => {
        this.nbrenseignants = res;
      })
    );

    const nbrDemandes$ = this.statsService.obtenirNbrDemandes().pipe(
      tap((res: any) => {
        this.nbrdemandes = res;
      })
    );

    const nbrDemandeApprouvees$ = this.statsService
      .obtenirNbrDemandeApprouvees()
      .pipe(
        tap((res: any) => {
          this.nbrdemandeapprouvees = res;
        })
      );

    const nbrDemandesEnAttente$ = this.statsService
      .obtenirNbrDemandesEnAttente()
      .pipe(
        tap((res: any) => {
          this.nbrdemandesenattente = res;
        })
      );

      const nbrDemandeRefusees = this.statsService
      .obtenirNbrDemandeRefusees()
      .pipe(
        tap((res: any) => {
          this.nbrdemanderefusees = res;
        })
      );


    return forkJoin([
      nbrUtilisateurs$,
      nbrEtudiants$,
      nbrEnseignants$,
      nbrDemandes$,
      nbrDemandeApprouvees$,
      nbrDemandesEnAttente$,
      nbrDemandeRefusees
    ]);
  }
}
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { modifierutilisateurComponent } from './modifierutilisateur.component';

describe('modifierutilisateurComponent', () => {
  let component: modifierutilisateurComponent;
  let fixture: ComponentFixture<modifierutilisateurComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ modifierutilisateurComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(modifierutilisateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

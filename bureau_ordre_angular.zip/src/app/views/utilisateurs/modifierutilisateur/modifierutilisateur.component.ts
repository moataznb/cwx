import { Component } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-modifierutilisateur',
  templateUrl: './modifierutilisateur.component.html',
  styleUrls: ['./modifierutilisateur.component.scss'],
})
export class modifierutilisateurComponent {
  modifierForm: any;
  userId: any;
  userdata:any;
  constructor(
    private utilisateurService: UtilisateurService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {

    this.route.params.subscribe((params) => {
      this.userId = params['id'];
      console.log(this.userId);
    });

    this.utilisateurService.afficherUtilisateurParID(this.userId).subscribe(
      (res) => {
        this.userdata = res;
        this.modifierForm.patchValue({
          nom: this.userdata.nom,
          prenom: this.userdata.prenom,
          email: this.userdata.email,
          cin: this.userdata.cin,
          phone: this.userdata.phone,
        });
      }
    );


    

    this.modifierForm = this.fb.group({
      nom: ['', Validators.required],
      prenom: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      cin: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(8),
          Validators.pattern('[0-9]*'),
        ],
      ],
      phone: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(8),
          Validators.pattern('[0-9]*'),
        ],
      ],
    });

   
  }

  modifierUtilisateur(modifierForm: any) {

    this.utilisateurService
      .modifierUtilisateurParID(this.userId, modifierForm)
      .subscribe(
        (res) => {
          alert('modifié');
          this.router.navigate(['/etudiants']);
        },
        (err) => {
          console.log(err);
          alert('Erreur lors de la modification');
        }
      );
  }

  cancel(){
    this.modifierForm.reset();
    this.router.navigate(['/utilisateurs']);
  }
}

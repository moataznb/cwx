import { Component } from '@angular/core';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-enseignants',
  templateUrl: './enseignants.component.html',
  styleUrls: ['./enseignants.component.scss'],
})
export class enseignantsComponent {
  constructor(private utilisateurService: UtilisateurService) {}
  listeEnseignants: any;
  listerEnseignants() {
    this.utilisateurService
      .afficherUtilisateurVerifiesParCategorie('Enseignant personnel')
      .subscribe((res) => {
        this.listeEnseignants = res;
        console.log(this.listeEnseignants);
      });
  }
  ngOnInit() {
    this.listerEnseignants();
  }

  supprimerEnseignant(id: any) {
    let confirmer = confirm('Voulez-vous vraiment supprimer cet étudiant?');
    if (confirmer) {
      this.utilisateurService.supprimerUtilisateurParID(id).subscribe((res) => {
        this.listerEnseignants();
        alert('supprimé!');
      });
    }
  }

  Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerEnseignants(); // Reset the table data to show all records
    } else {
      this.listeEnseignants = this.listeEnseignants.filter((etudiant:any) => {
        // Check if any attribute in the 'etudiant' object contains the 'filterValue'
        for (const attribute in etudiant) {
          if (
            etudiant.hasOwnProperty(attribute) &&
            typeof etudiant[attribute] === 'string' &&
            etudiant[attribute].toLowerCase().includes(filterValue)
          ) {
            return true;
          }
        }
        return false;
      });
    }
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { enseignantsComponent } from './enseignants.component';

describe('enseignantsComponent', () => {
  let component: enseignantsComponent;
  let fixture: ComponentFixture<enseignantsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ enseignantsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(enseignantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

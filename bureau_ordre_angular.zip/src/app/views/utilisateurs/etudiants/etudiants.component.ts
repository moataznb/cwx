import { Component } from '@angular/core';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-etudiants',
  templateUrl: './etudiants.component.html',
  styleUrls: ['./etudiants.component.scss'],
})
export class etudiantsComponent {
  constructor(private utilisateurService: UtilisateurService) {}
  listeEtudiants: any;
  listerEtudiants() {
    this.utilisateurService
      .afficherUtilisateurVerifiesParCategorie('Etudiant')
      .subscribe((res) => {
        this.listeEtudiants = res;
        console.log(this.listeEtudiants);
      });
  }
  ngOnInit() {
    this.listerEtudiants();
  }

  supprimerEtudiant(id: any) {
    let confirmer = confirm('Voulez-vous vraiment supprimer cet étudiant?');
    if (confirmer) {
      this.utilisateurService.supprimerUtilisateurParID(id).subscribe((res) => {
        this.listerEtudiants();
        alert('supprimé!');
      });
    }
  }

  Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerEtudiants(); // Reset the table data to show all records
    } else {
      this.listeEtudiants = this.listeEtudiants.filter((etudiant:any) => {
        // Check if any attribute in the 'etudiant' object contains the 'filterValue'
        for (const attribute in etudiant) {
          if (
            etudiant.hasOwnProperty(attribute) &&
            typeof etudiant[attribute] === 'string' &&
            etudiant[attribute].toLowerCase().includes(filterValue)
          ) {
            return true;
          }
        }
        return false;
      });
    }
  }
}


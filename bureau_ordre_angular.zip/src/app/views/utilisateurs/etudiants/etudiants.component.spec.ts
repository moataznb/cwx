import { ComponentFixture, TestBed } from '@angular/core/testing';

import { etudiantsComponent } from './etudiants.component';

describe('etudiantsComponent', () => {
  let component: etudiantsComponent;
  let fixture: ComponentFixture<etudiantsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ etudiantsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(etudiantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

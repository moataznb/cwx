import { Component } from '@angular/core';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-demandes_adhesion',
  templateUrl: './demandes_adhesion.component.html',
  styleUrls: ['./demandes_adhesion.component.scss'],
})
export class demandesAdhesionComponent {
  constructor(private utilisateurService: UtilisateurService) {}
  listeDemandes: any;
  listerDemandes() {
    this.utilisateurService
      .afficherUtilisateurNonVerifies()
      .subscribe((res) => {
        this.listeDemandes = res;
      });
  }
  ngOnInit() {
    this.listerDemandes();
  }

  autoriserDemande(id: any) {
    console.log(id);
    this.utilisateurService.confirmerUtilisateur(id).subscribe((res) => {
      this.listerDemandes();
      alert("demande acceptée");
    });
  }

  refuserDemande(id: any) {
    this.utilisateurService.supprimerUtilisateurParID(id).subscribe((res) => {
      this.listerDemandes();
      alert('demande refusée');
    });
  }

    Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerDemandes(); // Reset the table data to show all records
    } else {
      this.listeDemandes = this.listeDemandes.filter((etudiant:any) => {
        // Check if any attribute in the 'etudiant' object contains the 'filterValue'
        for (const attribute in etudiant) {
          if (
            etudiant.hasOwnProperty(attribute) &&
            typeof etudiant[attribute] === 'string' &&
            etudiant[attribute].toLowerCase().includes(filterValue)
          ) {
            return true;
          }
        }
        return false;
      });
    }
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { demandesAdhesionComponent } from './demandes_adhesion.component';

describe('demandesAdhesionComponent', () => {
  let component: demandesAdhesionComponent;
  let fixture: ComponentFixture<demandesAdhesionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ demandesAdhesionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(demandesAdhesionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

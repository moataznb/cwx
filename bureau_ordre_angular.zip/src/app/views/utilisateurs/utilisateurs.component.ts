import { Component } from '@angular/core';
import { UtilisateurService } from 'src/app/utilisateur.service';
import { LoginService } from 'src/app/login.service';
@Component({
  selector: 'app-utilisateurs',
  templateUrl: './utilisateurs.component.html',
  styleUrls: ['./utilisateurs.component.scss'],
})
export class UtilisateursComponent {
  userId: any;
  constructor(
    private utilisateurService: UtilisateurService,
    private loginService: LoginService
  ) {}
  listeUtilisateurs: any;
  listerUtilisateurs() {
    this.utilisateurService.listerUtilisateurs().subscribe((res) => {
      this.listeUtilisateurs = res;
      console.log(this.listeUtilisateurs);
    });
  }
  ngOnInit() {
    this.userId = this.loginService.getID();
    this.listerUtilisateurs();
  }

  supprimerEtudiant(id: any) {
    let confirmer = confirm('Voulez-vous vraiment supprimer cet étudiant?');
    if (confirmer) {
      this.utilisateurService.supprimerUtilisateurParID(id).subscribe((res) => {
        this.listerUtilisateurs();
        alert('supprimé!');
      });
    }
  }

  Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerUtilisateurs(); // Reset the table data to show all records
    } else {
      this.listeUtilisateurs = this.listeUtilisateurs.filter(
        (etudiant: any) => {
          // Check if any attribute in the 'etudiant' object contains the 'filterValue'
          for (const attribute in etudiant) {
            if (
              etudiant.hasOwnProperty(attribute) &&
              typeof etudiant[attribute] === 'string' &&
              etudiant[attribute].toLowerCase().includes(filterValue)
            ) {
              return true;
            }
          }
          return false;
        }
      );
    }
  }
}


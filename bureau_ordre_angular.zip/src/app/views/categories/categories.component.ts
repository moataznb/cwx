import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { categorieService } from 'src/app/categorie.service';
import { LoginService } from 'src/app/login.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss'],
})
export class CategoriesComponent {
  userId: any;
  afficher_formajout: any;
  constructor(
    private categorieService: categorieService,
    private http: HttpClient,
    private loginService: LoginService,
    private fb: FormBuilder
  ) {}

  categories: any;
  ajoutForm: any;
  listerCategories() {
    this.categorieService.lireCategories().subscribe((res) => {
      this.categories = res;
    });
  }

  ngOnInit() {
    this.listerCategories();
    this.afficher_formajout = false;
    this.ajoutForm = this.fb.group({
      nom: ['', Validators.required],
    });
  }

  supprimerCategorie(id: any) {
    let confirmer = confirm('Voulez-vous vraiment supprimer cette categorie?');

    if (confirmer) {
      this.categorieService.supprimerCategorie(id).subscribe((res) => {
        this.listerCategories();
        alert('suprimée!');
      });
    }
  }

  ajouterCategorie(f: any) {
    console.log(f);
    this.categorieService.ajouterCategorie(f).subscribe(
      (res) => {
        alert('catégorie ajouté');
        this.listerCategories();
      },
      (err) => {
        alert("erreur lors de l'ajout");
      }
    );
  }

  ajouter() {
    this.afficher_formajout = !this.afficher_formajout;
  }

  Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerCategories(); // Reset the table data to show all records
    } else {
      this.categories = this.categories.filter((categorie: any) => {
        // Check if any attribute in the 'etudiant' object contains the 'filterValue'
        for (const attribute in categorie) {
          if (
            categorie.hasOwnProperty(attribute) &&
            typeof categorie[attribute] === 'string' &&
            categorie[attribute].toLowerCase().includes(filterValue)
          ) {
            return true;
          }
        }
        return false;
      });
    }
  }

}


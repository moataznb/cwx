import { ComponentFixture, TestBed } from '@angular/core/testing';

import { modifiercategoriedemandeComponent } from './modifiercategoriedemande.component';

describe('modifiercategoriedemandeComponent', () => {
  let component: modifiercategoriedemandeComponent;
  let fixture: ComponentFixture<modifiercategoriedemandeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ modifiercategoriedemandeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(modifiercategoriedemandeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

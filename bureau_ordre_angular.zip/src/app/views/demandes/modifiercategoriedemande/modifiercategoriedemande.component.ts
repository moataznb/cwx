import { Component } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { categorieService } from 'src/app/categorie.service';
import { demandeService } from 'src/app/demande.service';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-modifiercategoriedemande',
  templateUrl: './modifiercategoriedemande.component.html',
  styleUrls: ['./modifiercategoriedemande.component.scss'],
})
export class modifiercategoriedemandeComponent {
  categorieForm: any;
  demandeId: any;
  demandeData: any;
  categories:any;
  constructor(
    private demandeService: demandeService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private utilisateurService: UtilisateurService,
    private CategorieService: categorieService
  ) {}

  lireCategories() {
    this.CategorieService.lireCategories().subscribe((res) => {
      this.categories = res;
    });
  }

  ngOnInit() {
    this.lireCategories();
    this.route.params.subscribe((params) => {
      this.demandeId = params['id'];
    });

    this.demandeService.obtenirDemandeParID(this.demandeId).subscribe((res) => {
      this.demandeData = res;
      console.log(this.demandeData);
    });

    this.categorieForm = this.fb.group({
      category: ['', Validators.required],
    });
  }

  modifiercategoriedemande(categorieForm: any) {
    let categorie = categorieForm.category;
    this.demandeService.modifiercategorie(this.demandeId, categorie).subscribe(
      (res: any) => {
        alert('Categorie de demande a eté avec succès.');
        this.router.navigate(['/demandes_approuvees']);
      },
      (err: any) => {
        alert("Erreur lors de l'approuvation");
      }
    );
  }

  telechargerFichier(fichier: any) {
    this.demandeService.telechargerFichier(fichier);
  }

  cancel() {
    this.categorieForm.reset();
    this.router.navigate(['/demandes']);
  }
}

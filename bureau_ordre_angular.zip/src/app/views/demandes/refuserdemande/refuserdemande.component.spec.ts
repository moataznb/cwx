import { ComponentFixture, TestBed } from '@angular/core/testing';

import { refuserdemandeComponent } from './refuserdemande.component';

describe('refuserdemandeComponent', () => {
  let component: refuserdemandeComponent;
  let fixture: ComponentFixture<refuserdemandeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ refuserdemandeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(refuserdemandeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { demandeService } from 'src/app/demande.service';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-refuserdemande',
  templateUrl: './refuserdemande.component.html',
  styleUrls: ['./refuserdemande.component.scss'],
})
export class refuserdemandeComponent {
  refuserForm: any;
  demandeId: any;
  demandeData: any;
  sendingEmail = false;
  constructor(
    private demandeService: demandeService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private utilisateurService: UtilisateurService
  ) {}

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.demandeId = params['id'];
      console.log(this.demandeId);
    });

    this.demandeService.obtenirDemandeParID(this.demandeId).subscribe((res) => {
      this.demandeData = res;

      console.log(this.demandeData);
    });

    this.refuserForm = this.fb.group({
      message: [''],
    });
  }

  refuserdemande(refuserForm: any) {
    this.demandeService
      .refuserDemande(this.demandeId)
      .subscribe(
        (res) => {
          alert('refusé');
          this.router.navigate(['/demandes']);
          if (this.sendingEmail && refuserForm.message.length > 0) {
            this.utilisateurService
              .envoyerMail({
                mailto: this.demandeData.sender.email,
                subject: 'Demande refusée',
                message: refuserForm.message,
              })
              .subscribe((res) => {
                console.log('email envoyé');
              });
          }
        },
        (err) => {
          console.log(err);
          alert("Erreur lors de l'approuvation");
        }
      );
  }

  telechargerFichier(fichier: any) {
    this.demandeService.telechargerFichier(fichier);
  }

  cancel() {
    this.refuserForm.reset();
    this.router.navigate(['/demandes']);
  }
}

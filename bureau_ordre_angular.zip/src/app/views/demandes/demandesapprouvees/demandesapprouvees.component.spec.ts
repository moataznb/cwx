import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemandesapprouveesComponent } from './demandesapprouvees.component';

describe('DemandesapprouveesComponent', () => {
  let component: DemandesapprouveesComponent;
  let fixture: ComponentFixture<DemandesapprouveesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DemandesapprouveesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DemandesapprouveesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

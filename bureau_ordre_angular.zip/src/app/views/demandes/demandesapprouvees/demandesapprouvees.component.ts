import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { categorieService } from 'src/app/categorie.service';
import { demandeService } from 'src/app/demande.service';

@Component({
  selector: 'app-demandesapprouvees',
  templateUrl: './demandesapprouvees.component.html',
  styleUrls: ['./demandesapprouvees.component.scss'],
})
export class DemandesapprouveesComponent {
  constructor(
    private demandeService: demandeService,
    private http: HttpClient,
    private CategorieService: categorieService
  ) {}
  demandesapprouvees: any;
  dernierecategorie: any;
  categories:any;

  listerLesDemandesapprouvees(categorie: any) {
    this.demandeService
      .listerDemandesVerifiesParCategorie(categorie)
      .subscribe((res) => {
        this.demandesapprouvees = res;
        console.log(this.demandesapprouvees);
      });
  }

  onCategorySelectChange(selectedValue: any) {
    let sel = selectedValue.target.value;
    if (sel !== null) {
      this.dernierecategorie = sel;
      this.listerLesDemandesapprouvees(sel);
    }
  }

  ngBefore() {
    this.listerLesDemandesapprouvees('all');
  }

  lireCategories() {
    this.CategorieService.lireCategories().subscribe((res) => {
      this.categories = res;
    });}
    

  ngOnInit() {
    this.lireCategories();
    this.dernierecategorie = 'all';
    this.listerLesDemandesapprouvees('all');
  }

  telechargerFichier(fichier: any) {
    this.demandeService.telechargerFichier(fichier);
  }

  supprimerDemande(id: any) {
    let confirmer = confirm('Voulez-vous vraiment supprimer cette demande?');

    if (confirmer) {
      this.demandeService.supprimerDemandeParID(id).subscribe((res) => {
        this.listerLesDemandesapprouvees(this.dernierecategorie);
        alert('suprimée!');
      });
    }
  }

  Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerLesDemandesapprouvees(this.dernierecategorie); // Reset the table data to show all records
    } else {
      this.demandesapprouvees = this.demandesapprouvees.filter(
        (mesdemande: any) => {
          // Check if any attribute in the 'etudiant' object contains the 'filterValue'
          for (const attribute in mesdemande) {
            if (
              mesdemande.hasOwnProperty(attribute) &&
              typeof mesdemande[attribute] === 'string' &&
              mesdemande[attribute].toLowerCase().includes(filterValue)
            ) {
              return true;
            }
          }
          return false;
        }
      );
    }
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { soumettredemandeComponent } from './soumettredemande.component';

describe('soumettredemandeComponent', () => {
  let component: soumettredemandeComponent;
  let fixture: ComponentFixture<soumettredemandeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ soumettredemandeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(soumettredemandeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

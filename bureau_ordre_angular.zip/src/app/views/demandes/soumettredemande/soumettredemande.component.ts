import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { demandeService } from 'src/app/demande.service';
import { LoginService } from 'src/app/login.service';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-soumettredemande',
  templateUrl: './soumettredemande.component.html',
  styleUrls: ['./soumettredemande.component.scss'],
})
export class soumettredemandeComponent {
  soumettreForm: any;
  demandeId: any;
  demandeData: any;
  sendingEmail = false;
  userId:any;
  constructor(
    private demandeService: demandeService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private utilisateurService: UtilisateurService,
    private loginService : LoginService,
    private http : HttpClient
  ) {}

  ngOnInit() {
  
    this.userId = this.loginService.getID();

  this.soumettreForm = this.fb.group({
    subject: ['', Validators.required],
    description: ['', Validators.required],
    sender: [this.userId],
    file: [null] // Set the initial value of the file FormControl to null
  });
}

 uploadFile(event: any) {
    const file = event.target.files ? event.target.files[0] : "";
    this.soumettreForm.patchValue({
      file: file,
    });
    this.soumettreForm.get("file")?.updateValueAndValidity();
  }






  soumettreDemande(soumettreForm: any) {
    soumettreForm.sender = this.userId;
  const formData = new FormData();
  formData.append('subject', soumettreForm.subject);
  formData.append('description', soumettreForm.description);
  formData.append('sender', this.userId);
  formData.append('file', soumettreForm.file);
    this.demandeService.ajouterDemande(formData).subscribe(
      (res) => {
        alert('demande ajouté');
      },
      (err) => {
        console.log(err);
        alert("Erreur lors de l'ajout");
      }
    );
  }

}

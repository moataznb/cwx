import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { demandeService } from 'src/app/demande.service';

@Component({
  selector: 'app-demandesrefusees',
  templateUrl: './demandesrefusees.component.html',
  styleUrls: ['./demandesrefusees.component.scss'],
})
export class DemandesrefuseesComponent {
  constructor(
    private demandeService: demandeService,
    private http: HttpClient
  ) {}
  demandesrefusees: any;
  listerLesDemandesrefusees() {
    this.demandeService.listerDemandesRefusees().subscribe((res) => {
      this.demandesrefusees = res;
      console.log(this.demandesrefusees);
    });
  }

  ngBefore() {
    this.listerLesDemandesrefusees();
  }

  ngOnInit() {
    this.listerLesDemandesrefusees();
  }

  telechargerFichier(fichier: any) {
    this.demandeService.telechargerFichier(fichier);
  }

  supprimerDemande(id: any) {
    let confirmer = confirm('Voulez-vous vraiment supprimer cette demande?');

    if (confirmer) {
      this.demandeService.supprimerDemandeParID(id).subscribe((res) => {
        this.listerLesDemandesrefusees();
        alert('suprimée!');
      });
    }
  }

  Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerLesDemandesrefusees(); // Reset the table data to show all records
    } else {
      this.demandesrefusees = this.demandesrefusees.filter(
        (mesdemande: any) => {
          // Check if any attribute in the 'etudiant' object contains the 'filterValue'
          for (const attribute in mesdemande) {
            if (
              mesdemande.hasOwnProperty(attribute) &&
              typeof mesdemande[attribute] === 'string' &&
              mesdemande[attribute].toLowerCase().includes(filterValue)
            ) {
              return true;
            }
          }
          return false;
        }
      );
    }
  }

}

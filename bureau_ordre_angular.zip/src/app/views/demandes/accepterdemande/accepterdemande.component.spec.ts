import { ComponentFixture, TestBed } from '@angular/core/testing';

import { accepterdemandeComponent } from './accepterdemande.component';

describe('accepterdemandeComponent', () => {
  let component: accepterdemandeComponent;
  let fixture: ComponentFixture<accepterdemandeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ accepterdemandeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(accepterdemandeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import { FormBuilder,FormGroup,Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { categorieService } from 'src/app/categorie.service';
import { demandeService } from 'src/app/demande.service';
import { UtilisateurService } from 'src/app/utilisateur.service';

@Component({
  selector: 'app-accepterdemande',
  templateUrl: './accepterdemande.component.html',
  styleUrls: ['./accepterdemande.component.scss'],
})
export class accepterdemandeComponent {
  accepterForm: any;
  demandeId: any;
  demandeData: any;
  sendingEmail = false;
  categories: any;
  constructor(
    private demandeService: demandeService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private utilisateurService: UtilisateurService,
    private CategorieService: categorieService
  ) {}

  lireCategories() {
    this.CategorieService.lireCategories().subscribe((res) => {
      this.categories = res;
    });
  }


  ngOnInit() {
    this.lireCategories();
    this.route.params.subscribe((params) => {
      this.demandeId = params['id'];
      console.log(this.demandeId);
    });

    this.demandeService.obtenirDemandeParID(this.demandeId).subscribe((res) => {
      this.demandeData = res;

      console.log(this.demandeData);
    });

    this.accepterForm = this.fb.group({
      category: ['', Validators.required],
      message: [''],
    });
  }

  accepterdemande(accepterForm: any) {
    this.demandeService
      .approuverDemande(this.demandeId, accepterForm)
      .subscribe(
        (res) => {
          alert('approuvé');
          this.router.navigate(['/etudiants']);
          if (this.sendingEmail && accepterForm.message) {
            this.utilisateurService
              .envoyerMail({
                mailto: this.demandeData.sender.email,
                subject: 'Demande approuvée',
                message: accepterForm.message,
              })
              .subscribe((res) => {
                console.log('email envoyé');
              });
          }
        },
        (err) => {
          console.log(err);
          alert("Erreur lors de l'approuvation");
        }
      );
  }

  telechargerFichier(fichier: any) {
    this.demandeService.telechargerFichier(fichier);
  }

  cancel() {
    this.accepterForm.reset();
    this.router.navigate(['/demandes']);
  }
}

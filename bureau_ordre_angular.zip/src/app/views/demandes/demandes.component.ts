import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { demandeService } from 'src/app/demande.service';

@Component({
  selector: 'app-demandes',
  templateUrl: './demandes.component.html',
  styleUrls: ['./demandes.component.scss'],
})
export class DemandesComponent {
  constructor(
    private demandeService: demandeService,
    private http: HttpClient
  ) {}
  demandes: any;
  listerLesDemandes() {
    this.demandeService.listerDemandesNonVerifies().subscribe((res) => {
      this.demandes = res;
      console.log(this.demandes);
    });
  }

  ngBefore(){
    this.listerLesDemandes();
  }

  ngOnInit() {
    this.listerLesDemandes();
  }

  telechargerFichier(fichier: any) {
    this.demandeService.telechargerFichier(fichier);
}

 Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerLesDemandes(); // Reset the table data to show all records
    } else {
      this.demandes = this.demandes.filter((demande: any) => {
        // Check if any attribute in the 'etudiant' object contains the 'filterValue'
        for (const attribute in demande) {
          if (
            demande.hasOwnProperty(attribute) &&
            typeof demande[attribute] === 'string' &&
            demande[attribute].toLowerCase().includes(filterValue)
          ) {
            return true;
          }
        }
        return false;
      });
    }
  }


}

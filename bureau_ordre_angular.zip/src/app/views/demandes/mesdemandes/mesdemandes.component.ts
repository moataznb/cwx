import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { demandeService } from 'src/app/demande.service';
import { LoginService } from 'src/app/login.service';

@Component({
  selector: 'app-mesdemandes',
  templateUrl: './mesdemandes.component.html',
  styleUrls: ['./mesdemandes.component.scss'],
})
export class MesdemandesComponent {
  userId: any;
  constructor(
    private demandeService: demandeService,
    private http: HttpClient,
    private loginService: LoginService
  ) {}

  mesdemandes: any;
  listerMesdemandes() {
    this.demandeService.listerDemandesParID(this.userId).subscribe((res) => {
      this.mesdemandes = res;
      console.log(this.mesdemandes);
    });
  }

  ngBefore() {
    this.listerMesdemandes();
  }

  ngOnInit() {
    this.userId = this.loginService.getID();
    this.listerMesdemandes();
  }

  telechargerFichier(fichier: any) {
    this.demandeService.telechargerFichier(fichier);
  }

  supprimerDemande(id: any) {
    let confirmer = confirm('Voulez-vous vraiment supprimer cette demande?');

    if (confirmer) {
      this.demandeService.supprimerDemandeParID(id).subscribe((res) => {
        this.listerMesdemandes();
        alert('suprimée!');
      });
    }
  }

  Rechercher(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value
      .trim()
      .toLowerCase();

    if (filterValue === '') {
      this.listerMesdemandes(); // Reset the table data to show all records
    } else {
      this.mesdemandes = this.mesdemandes.filter((mesdemande: any) => {
        // Check if any attribute in the 'etudiant' object contains the 'filterValue'
        for (const attribute in mesdemande) {
          if (
            mesdemande.hasOwnProperty(attribute) &&
            typeof mesdemande[attribute] === 'string' &&
            mesdemande[attribute].toLowerCase().includes(filterValue)
          ) {
            return true;
          }
        }
        return false;
      });
    }
  }

}

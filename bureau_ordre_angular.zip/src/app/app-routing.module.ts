import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DefaultLayoutComponent } from './containers';
import { Page404Component } from './views/pages/page404/page404.component';
import { LoginComponent } from './views/pages/login/login.component';
import { RegisterComponent } from './views/pages/register/register.component';
import { UtilisateursComponent } from './views/utilisateurs/utilisateurs.component';
import { demandesAdhesionComponent } from './views/utilisateurs/demandes_adhesion/demandes_adhesion.component';
import { enseignantsComponent } from './views/utilisateurs/enseignants/enseignants.component';
import { etudiantsComponent } from './views/utilisateurs/etudiants/etudiants.component';
import { DemandesComponent } from './views/demandes/demandes.component';
import { AuthGuard } from './auth.guard';
import { LoggedGuard } from './logged.guard';
import { adminGuard } from './admin.guard';
import { modifierutilisateurComponent } from './views/utilisateurs/modifierutilisateur/modifierutilisateur.component';
import { accepterdemandeComponent } from './views/demandes/accepterdemande/accepterdemande.component';
import { refuserdemandeComponent } from './views/demandes/refuserdemande/refuserdemande.component';
import { soumettredemandeComponent } from './views/demandes/soumettredemande/soumettredemande.component';
import { DemandesrefuseesComponent } from './views/demandes/demandesrefusees/demandesrefusees.component';
import { ProfileComponent } from './views/pages/profile/profile.component';
import { MesdemandesComponent } from './views/demandes/mesdemandes/mesdemandes.component';
import { DemandesapprouveesComponent } from './views/demandes/demandesapprouvees/demandesapprouvees.component';
import { modifiercategoriedemandeComponent } from './views/demandes/modifiercategoriedemande/modifiercategoriedemande.component';
import { ModifiermotdepasseComponent } from './views/pages/modifiermotdepasse/modifiermotdepasse.component';
import { MotdepasseoublieComponent } from './views/pages/motdepasseoublie/motdepasseoublie.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { CategoriesComponent } from './views/categories/categories.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent, canActivate: [LoggedGuard] },
  {
    path: 'register',
    component: RegisterComponent,
    canActivate: [LoggedGuard],
  },
  {
    path: 'motdepasseoublie',
    component: MotdepasseoublieComponent,
    canActivate: [LoggedGuard],
  },
  { path: '404', component: Page404Component, canActivate: [LoggedGuard] },
  {
    path: '',
    canActivate: [AuthGuard],
    component: DefaultLayoutComponent,
    data: {
      title: 'Home',
    },
    children: [
      {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'profile',
        component: ProfileComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'modifiermotdepasse',
        component: ModifiermotdepasseComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'demandes',
        component: DemandesComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'demandes_refusees',
        component: DemandesrefuseesComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'demandes_approuvees',
        component: DemandesapprouveesComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'categories',
        component: CategoriesComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'utilisateurs',
        component: UtilisateursComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'etudiants',
        component: etudiantsComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'modifier/:id',
        component: modifierutilisateurComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'modifiercategorie/:id',
        component: modifiercategoriedemandeComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'accepter/:id',
        component: accepterdemandeComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'refuser/:id',
        component: refuserdemandeComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'soumettre',
        component: soumettredemandeComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'enseignants',
        component: enseignantsComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'demandes_adhesion',
        component: demandesAdhesionComponent,
        canActivate: [adminGuard],
      },
      {
        path: 'mes_demandes',
        component: MesdemandesComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'top',
      anchorScrolling: 'enabled',
      initialNavigation: 'enabledBlocking'
      // relativeLinkResolution: 'legacy'
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {
}

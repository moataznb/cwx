import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UtilisateurService {
  private apiUrl: string = "http://localhost:3000/api/utilisateurs"

  constructor(private http: HttpClient) {}

  // Add a new user
  ajouterUtilisateur(utilisateur: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/utilisateur`, utilisateur);
  }

  // Get all users
  listerUtilisateurs(): Observable<any> {
    return this.http.get(`${this.apiUrl}/utilisateur`);
  }

  // Get a user by ID
  afficherUtilisateurParID(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/utilisateur/${id}`);
  }

  // Update a user by ID
  modifierUtilisateurParID(id: string, utilisateur: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/utilisateur/${id}`, utilisateur);
  }

  // Delete a user by ID
  supprimerUtilisateurParID(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/utilisateur/${id}`);
  }

  // Register a new user
  inscrireUtilisateur(utilisateur: any): Observable<any> {
    return this.http.post(
      'http://localhost:3000/api/utilisateurs/inscrire',
      utilisateur
    );
  }

  // Confirm a user by ID
  confirmerUtilisateur(id: string): Observable<any> {
    return this.http.put(`${this.apiUrl}/confirmer/${id}`, null);
  }

  // Get verified users
  afficherUtilisateurVerifies(): Observable<any> {
    return this.http.get(`${this.apiUrl}/verifies`);
  }

  // Get unverified users
  afficherUtilisateurNonVerifies(): Observable<any> {
    return this.http.get(`${this.apiUrl}/nonverifies`);
  }

  // Get verified users by category
  afficherUtilisateurVerifiesParCategorie(role: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/verifiesparrole/${role}`);
  }

  envoyerMail(mailinfo: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/envoyermail/`, mailinfo);
  }

  modifierMotdepass(id: string, utilisateur: any): Observable<any> {
    return this.http.put(
      `${this.apiUrl}/modifiermotdepasse/${id}`,
      utilisateur
    );
  }

  motdepasseoublie(emailinfo:any): Observable<any>{
    return this.http.post(`${this.apiUrl}/reinitialisermotdepasse/`, emailinfo);
  }



}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class demandeService {
  private apiUrl: string = 'http://localhost:3000/api/demandes';
  constructor(private http: HttpClient) {}

  // Add a new user
  ajouterDemande(demande: any) {
    return this.http.post(`${this.apiUrl}/demandes`, demande);
  }

  // Get all users
  listerDemandes(): Observable<any> {
    return this.http.get(`${this.apiUrl}/demandes`);
  }

  // supprimer Demande
  supprimerDemandeParID(id: string) {
    return this.http.delete(`${this.apiUrl}/demande/${id}`);
  }

  //approuverDemande
  approuverDemande(id: string, demande: any) {
    return this.http.put(`${this.apiUrl}/demande/${id}/approuver/`, demande);
  }

  obtenirDemandeParID(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/demande/${id}`);
  }

  //refuserDemande
  refuserDemande(id: string) {
    return this.http.put(`${this.apiUrl}/demande/${id}/refuser/`, null);
  }

  //lister demandes d'un utilisateur par son ID
  listerDemandesParID(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/demandesutilisateur/${id}`);
  }

  //lister demandes non verifies
  listerDemandesNonVerifies(): Observable<any> {
    return this.http.get(`${this.apiUrl}/demandes/en-attente`);
  }

  //lister demandes verifies par categorie
  listerDemandesVerifiesParCategorie(category: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/demandes/verifies/${category}`);
  }

  telechargerFichier(fileUrl: string): void {
    this.http
      .get('http://localhost:3000/uploads/' + fileUrl, { responseType: 'blob' })
      .subscribe((response: Blob) => {
        // Create a download link
        const link = document.createElement('a');
        link.href = window.URL.createObjectURL(response);
        link.download = this.getFileNameFromUrl(fileUrl);

        // Append the link to the DOM and trigger the download
        document.body.appendChild(link);
        link.click();

        // Clean up
        document.body.removeChild(link);
      });
  }

  getFileNameFromUrl(url: string): string {
    // Extracts the file name from the URL
    const parts = url.split('/');
    return parts[parts.length - 1];
  }

  //lister demandes refusées
  listerDemandesRefusees(): Observable<any> {
    return this.http.get(`${this.apiUrl}/demandesrefusees`);
  }

  modifiercategorie(id: string, categorie: any): Observable<any> {
    return this.http.put(
      `${this.apiUrl}/demande/${id}/modifiercategorie/${categorie}`,
      null
    );
  }
}   
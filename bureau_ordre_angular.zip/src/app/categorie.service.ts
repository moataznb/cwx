import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})

export class categorieService {
  private apiUrl: string = 'http://localhost:3000/api/categories';

  constructor(private http: HttpClient) {}

  lireCategories(): Observable<any> {
    return this.http.get(this.apiUrl + '/categories');
  }

  ajouterCategorie(categorie:any) {
    return this.http.post(this.apiUrl + '/categories',categorie);
  }

  supprimerCategorie(idcategorie:any): Observable<any> {
    return this.http.delete( `${this.apiUrl}/supprimer/${idcategorie}`);
  }

}

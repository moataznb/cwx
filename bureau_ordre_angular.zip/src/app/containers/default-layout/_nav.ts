import { INavData } from '@coreui/angular';


export const navItemsAdmin: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-home' },
  },
  {
    name: 'Gestion des catégories',
    url: '/categories',
    iconComponent: { name: 'cil-paperclip' },
  },
  {
    title: true,
    name: 'Gestion des demandes',
  },
  {
    name: 'Les demandes en attente',
    url: '/demandes',
    iconComponent: { name: 'cil-notes' },
  },

  {
    name: 'Les demandes refusées',
    url: '/demandes_refusees',
    iconComponent: { name: 'cil-notes' },
  },
  {
    name: 'Les demandes approuvées',
    url: '/demandes_approuvees',
    iconComponent: { name: 'cil-notes' },
  },

  {
    name: 'Gestion des utilisateurs',
    title: true,
  },
  {
    name: 'Utilisateurs',
    url: '/utilisateurs',
    iconComponent: { name: 'cil-user' },
    children: [
      {
        name: 'Tous les utilisateurs',
        url: '/utilisateurs',
      },
      {
        name: 'Etudiants',
        url: '/etudiants',
      },
      {
        name: 'Enseignants',
        url: '/enseignants',
      },
    ],
  },
  {
    name: "Demandes d'adhésion",
    url: '/demandes_adhesion',
    iconComponent: { name: 'cil-user-follow' },
  },
];



export const navItemsUser: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    iconComponent: { name: 'cil-home' },
  },
  {
    name: 'Mon espace',
    title: true,
  },
  {
    name: 'Mes demandes',
    url: '/mes_demandes',
    iconComponent: { name: 'cil-envelope-closed' },
    badge: {
      color: 'info',
      text: '0',
    },
  },

  {
    name: 'Soumettre une demande',
    url: '/soumettre',
    iconComponent: { name: 'cil-envelope-closed' },
  },
];

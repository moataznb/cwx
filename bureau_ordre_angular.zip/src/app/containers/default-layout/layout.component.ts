import { Component } from '@angular/core';

import { navItemsAdmin, navItemsUser } from './_nav';
import { LoginService } from 'src/app/login.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './layout.component.html',
})
export class DefaultLayoutComponent {
  userrole:any;
  public navItemsAdmin = navItemsAdmin;
  public navItemsUser = navItemsUser;
  public perfectScrollbarConfig = {
    suppressScrollX: true,
  };

  constructor(private ls : LoginService) {
    this.userrole = this.ls.getRole();
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class statistiquesService {
  private apiUrl: string = "http://localhost:3000/api/informations";

  constructor(private http: HttpClient) {}

  obtenirNbrUtilisateurs(): Observable<any> {
    return this.http.get(this.apiUrl + '/nombreutilisateurs'); 
  }

  obtenirNbrEtudiants() : Observable<any> {
    return this.http.get(this.apiUrl + '/nombredesetudiants');
  }

  obtenirNbrEnseignants() : Observable<any> {
    return this.http.get(this.apiUrl + '/nombredesenseignants');
}



  obtenirNbrDemandes(): Observable<any> {
    return this.http.get(this.apiUrl + '/nombredemandes'); 
  }

  obtenirNbrDemandesEnAttente(): Observable<any> {  
    return this.http.get(this.apiUrl + '/nombredemandesenattente'); 
  }

  obtenirNbrDemandeApprouvees(): Observable<any> {
    return this.http.get(this.apiUrl + '/nombredemandesapprouvees'); 
  }

  obtenirNbrDemandeRefusees(): Observable<any> {
    return this.http.get(this.apiUrl + '/nombredemanderefuses'); 
  }




}